from multiprocessing import Process
import time

def primeiro():
	time.sleep(1)
	print("Esta linha deve aparecer primeiro.")


def segundo():
	print("Esta linha deve aparecer em ultimo!")

seg = Process(target=segundo)
prim = Process(target=primeiro)

seg.start()
prim.start()

prim.join()
seg.join()
