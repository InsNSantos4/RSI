from multiprocessing import Process, Array, Semaphore
import random, time

MAX_SIZE = 5

myBuffer = Array("i",MAX_SIZE)

mutex = Semaphore(1)
empty = Semaphore(MAX_SIZE) #Inicialmente, MAX_SIZE posicoes livres
full = Semaphore(0) #Inicialmente, 0 posicoes ocupadas

def produtor():
	inPosition = 0
	while True:
		nextProduced = random.randint(1,100)
		empty.acquire() #Ha posicoes livres?
		mutex.acquire()
		myBuffer[inPosition] = nextProduced
		print("+++Produzi " + str(nextProduced) + " na posicao " + str(inPosition))
		inPosition = (inPosition + 1) % MAX_SIZE
		mutex.release()
		full.release()#Informo que ha nova posicao ocupada
 		time.sleep(random.randint(0,3))

def consumidor():
	outPosition = 0
	while True:
		mutex.acquire()
		full.acquire()#Ha posicoes ocupadas?
		nextConsumed = myBuffer[outPosition]
		print("---Consumi " + str(nextConsumed) + " na posicao " + str(outPosition))
		outPosition = (outPosition + 1) % MAX_SIZE
		mutex.release()
		empty.release()#Informo que ha nova posicao livre
		time.sleep(random.randint(0,3))

prod = Process(target=produtor)
cons = Process(target=consumidor)

prod.start()
cons.start()

prod.join()
cons.join()
