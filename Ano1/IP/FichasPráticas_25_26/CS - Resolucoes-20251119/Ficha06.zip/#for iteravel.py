# Exemplos de Ciclos for variavel_iteração  in iteravel

# este progrma itera uma string
print( '\nComando: for i in STRING')
input('.....Press Enter to Start')
for i in 'Introdução à Programação':
    print(i)

