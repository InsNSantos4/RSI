#
# POP Setembro 2023
#
# IP Ficha 03  Exercicio 02
#
# Existe alguma diferença no funcionamento dos seguintes extratos de código?
# if x = = 0:           if x = 0:
#    print(“X”)            print(“X”)
# else:                 else:
#     print(“Y”)           print(“Y”)
#
if x = 0:
    print("X")
else:
    print("Y")
