#
# POP Setembro 2022
#
# IP Ficha 03  Exercicio 04
#
#  Reescreva o código seguinte utilizando um único if:
#   if x == 0:
#       if y <= 32:
#          print(“Sucesso!”)

if x == 0 and  y <= 32:
    print(“Sucesso!”)

# fim do programa