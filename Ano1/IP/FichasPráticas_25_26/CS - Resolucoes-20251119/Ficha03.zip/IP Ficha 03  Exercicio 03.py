#
# POP Setembro 2022
#
# IP Ficha 03  Exercicio 03
#
#  Qual o valor lógico que as seguintes expressões enviam para o if?

# a) if 10 == 5:
print("o valor lógico que a expressão  10==5  envia para o if:" )
if 10 == 5:
    print(True)
else:
    print(False)
print()

#   b) if (2+3) = = -(-2-3):
print("o valor lógico que a expressão  (2+3) = = -(-2-3)  envia para o if:" )
if (2+3) == -(-2-3):
    print(True)
else:
    print(False)
print()



#   d) if -1:
print("o valor lógico que a expressão  -1  envia para o if:" )
if -1:
    print(True)
else:
    print(False)
print()


#   c) if x == 5:
print("o valor lógico que a expressão  x == 5 envia para o if:" )
if x == 5:
    print(True)
else:
    print(False)
print()
