#
# POP Setembro 2022
#
# IP Ficha 03  Exercicio 05
#
#  Identifique os erros de compilação que seriam detetados no programa seguinte:
#  if x = = 0;
#    print(“X é zero\n”)
#  else
#   print(“X não é zero\n”)
x=0
s = x == 1
if x == 0:
   print("X é zero\n")
else:
   print("X não é zero\n")

# fim do programa