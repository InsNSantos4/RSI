# POP 2023
# Ficha 05 ex 11

# Pirâmide de Asteriscos
# Escreva um programa que coloque no ecrã meia árvore de Natal com asteriscos. O
# número de ramos deverá ser introduzido pelo utilizador.

print('Pirâmide de Asteriscos - meia árvore de Natal ')
n = int(input('Introduza o numero de ramos: '))

for i in range(1,n+1):
    print("*"*i )


#fim

