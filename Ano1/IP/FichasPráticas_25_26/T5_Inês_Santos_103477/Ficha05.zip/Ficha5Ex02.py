#Fich05 Ex5
#POP 23


# Numeros de 1 a 100

# a) Ciclo while:
print('** Ciclo while:')
i=1
while i <= 100:
    print(i)
    i +=1    # i=i+1

# b) Ciclo for:
print('\n** Ciclo for:')
for i in range(1,101):
    print(i)


# c) Ciclo while:
print('\n** Ciclo while inverso:')
i=100
while i >= 1:
    print(i)
    i -= 1    # i=i- 1

# c) Ciclo for:
print('\n** Ciclo for inverso:')
for i in range(100,0,-1):
    print(i)

