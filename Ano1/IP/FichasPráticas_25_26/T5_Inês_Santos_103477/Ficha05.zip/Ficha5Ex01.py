# POP 2023
# Ficha 05 ex 01

#Reescreva o seguinte código utilizando o ciclo while:
for i in range(20):
    if i == 10:
        print("\n")
    else:
        print("%d"%i)

# Com ciclo while:

i = 0
while i < 20:
    if i == 10:
        print("\n")
    else:
        print("%d"%i)
    i += 1
