#
# POP Setembro 2022
#
# IP Ficha 02  Exercicio 09
#
# 9. Identifique os erros de compilação que seriam detetados nos seguintes programas:
#       a.	print("4"+3)
#       b.	n=input(""), print(n)
#       c.	n=5
#           print("Output\n%d"%n)
#       d.	a=input("a?")
#           b=3
#           print("Soma= {}".format(a+b))

x = 5
print("Output\n%d" % x)
