numerador = 10
denominador = 0
try:
    result = numerador/denominador
except: # ValueError: #ZeroDivisionError:
    print('O denominador não pode ser zero')