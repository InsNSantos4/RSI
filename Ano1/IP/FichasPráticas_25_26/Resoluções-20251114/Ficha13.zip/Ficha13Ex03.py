# Ficha  Ex 03


try:
    num = int(input('Digite um numero: '))
    print(num + 1)
except TypeError:
    print(' Ocorreu um erro: Tipo de valor inválido')
except :
    print(' Ocorreu um erro!')


