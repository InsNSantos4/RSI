# Ficha 7 Ex13

print("»»»»»»  Este programa converte numeros de base 16, 8 e 2 para base 10")
print("»»»»»»\n ")
cadeia = input('Introduza a cadeia de caracteres: ')

print(hex(255))