# Ficha 7 Ex02


cadeia = input('Introduza a cadeia de catacteres: ')
a= len(cadeia)
print("len(cadeia): ",a)

for i in range(len(cadeia)):



    print(cadeia[0:i+1])

#     print(i,end='')
#    print(cadeia[0:i+1])
#    print(cadeia[:i])

#    print(cadeia[i])