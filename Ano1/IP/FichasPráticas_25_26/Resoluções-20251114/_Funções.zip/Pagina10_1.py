import math
radians = 0
x=math.cos(radians)
print(x)

golden=(math.sqrt(5)+1)/2
print(golden)

