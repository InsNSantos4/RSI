import math
def print_twice(bruce):
    print(bruce)
    print(bruce)

A = 2
print_twice(A)

print_twice('spam'*4)

print_twice(math.cos(math.pi))