def print_twice(bruce):
    print(bruce)
    print(bruce)
def cat_twice (part1,part2):
    cat = part1 + part2
    print_twice(cat)

linha1 ='Ola '
linha2 ='Bom dia'

cat_twice(linha1,linha2)
print(cat)


