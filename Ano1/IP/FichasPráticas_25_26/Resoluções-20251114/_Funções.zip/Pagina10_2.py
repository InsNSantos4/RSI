def print_twice(bruce):
    print(bruce)
    print(bruce)

result= print_twice('Bing')
print(result)


