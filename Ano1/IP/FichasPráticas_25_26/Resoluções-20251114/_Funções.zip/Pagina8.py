def print_twice(bruce):
    print(bruce)
    print(bruce)


michael = 'Eric, the half a bee'
print_twice(michael)
