

a=[1,2,3]
b=[4,5,6.9]
a_soma = sum(a)
b_soma = sum(b)
a_maximo = max(a)
b_minimo = min(b)

c=a+b
e=3*a

f = a[-1]
g=c[0:7] # o 7 é maior que len(c)
h=a
h1=a[:]
h.append(b)
j=a
j.extend(b)
k=e.copy()
k.sort()
l=k.pop(3)
del k[1:4]
del k[-1]
m=['a']+k
m.remove('a')
st='  boa noite  malta  '
n=list(st)
o=st.split()
p=st.split('o')
q=st.split('oa')
r=' '.join(o)
s= '--'
t=s.join(o)


u=a[3]
v=u[2]
v1=a[3][2]
z1=st[::-1]
z2=st[::-2]
z3=st[2:8:-2]
z4=st[8:2:-1]
z5=st[8:2:-2]
z6=st[len(st)::-1]
z7=st[-8:-1:1]
z78=st[-1:-8:-1]
input("fim")

