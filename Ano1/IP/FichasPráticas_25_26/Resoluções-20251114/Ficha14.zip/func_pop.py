# Modulo de funções

# contador
# recebe como argumento um iteravel e retorma dicionario com o nº de ocorrencias de cada item

def contador(inp):
    #  inp = sorted(inp) # sort para o
    hist = {}
    for x in inp:
        if x in hist:  # se o valor já existe no dicionáro, adiciona mais uma ocorrência
            hist[x] += 1
        else: # se o valor não existe no dicionáro, cria nova entrada com valor 1
            hist[x] = 1
    return hist