lista_com_repeticoes = [1, 2, 2, 3, 4, 4, 5]
print('Lista com repeticoes: ',lista_com_repeticoes )

# Criar um dicionario com base na lista ementos repetidos
dic ={}
for i in lista_com_repeticoes :
    dic[i]= 0

# converter dicionário em lista, já sem repetições
lista_sem_repeticoes =list(dic)
print('Lista sem repeticoes: ',lista_sem_repeticoes)


# Outra forma (usando set):

# Convertendo a lista para um conjunto para remover elementos repetidos
conjunto_sem_repeticoes = set(lista_com_repeticoes)

# Convertendo o conjunto de volta para uma lista
lista_sem_repeticoes = list(conjunto_sem_repeticoes)
print('Lista sem repeticoes: ',lista_sem_repeticoes)
#numa só linha:
conjunto_sem_repeticoes=list(set(lista_com_repeticoes))
print('Lista sem repeticoes: ',lista_sem_repeticoes)

# Outra forma (comprehension list):
lista_sem_repeticoes = list(dict.fromkeys(lista_com_repeticoes))
print('Lista sem repeticoes: ',lista_sem_repeticoes)