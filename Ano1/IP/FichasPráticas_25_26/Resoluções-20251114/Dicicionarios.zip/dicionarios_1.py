
a={'one':'uno','two':'dos','three':'tres'}
print(a)
print('Keys:')
for i in a:
    print(i)

input('     Enter para continuar')

print('Values:')
for i in a:
    print(a[i])

input('     Enter para continuar')

print('Keys  --  Values:')
for i in a:
    print(i,'--',a[i])

